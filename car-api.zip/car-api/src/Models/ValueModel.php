<?php

namespace Vanier\Api\Models;
use Vanier\Api\Models\BaseModel;


class ValueModel extends BaseModel{
    


private $table_name="Value";

public function __construct()
    {
    
        parent::__construct();
    }


    






}