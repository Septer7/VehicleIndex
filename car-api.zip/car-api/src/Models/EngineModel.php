<?php

namespace Vanier\Api\Models;
use Vanier\Api\Models\BaseModel;


class EngineModel extends BaseModel{
    


private $table_name="Engine";

public function __construct()
    {
    
        parent::__construct();
    }


   






}