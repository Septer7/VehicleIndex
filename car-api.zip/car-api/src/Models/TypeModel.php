<?php

namespace Vanier\Api\Models;
use Vanier\Api\Models\BaseModel;


class TypeModel extends BaseModel{
    


private $table_name="Type";

public function __construct()
    {
    
        parent::__construct();
    }


   






}