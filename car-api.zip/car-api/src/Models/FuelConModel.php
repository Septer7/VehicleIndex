<?php

namespace Vanier\Api\Models;
use Vanier\Api\Models\BaseModel;


class FuelConModel extends BaseModel{
    


private $table_name="Fuel_Consumption";

public function __construct()
    {
    
        parent::__construct();
    }


    






}