<?php

namespace Vanier\Api\Models;
use Vanier\Api\Models\BaseModel;


class ElectricityConModel extends BaseModel{
    


private $table_name="Electricity_Consumption";

public function __construct()
    {
    
        parent::__construct();
    }


    






}