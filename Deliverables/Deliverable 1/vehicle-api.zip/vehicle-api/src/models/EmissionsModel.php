<?php

namespace Vanier\Api\Models;
use Vanier\Api\Models\BaseModel;


class EmissionsModel extends BaseModel{
    


private $table_name="Emissions";

public function __construct()
    {
    
        parent::__construct();
    }


    






}